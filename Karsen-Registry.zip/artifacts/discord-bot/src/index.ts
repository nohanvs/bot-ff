import {
  Client,
  GatewayIntentBits,
  Partials,
  Events,
  StringSelectMenuInteraction,
  ButtonInteraction,
  ModalSubmitInteraction,
  ChatInputCommandInteraction,
} from "discord.js";

import { initDatabase } from "./database/db.js";
import { onReady } from "./events/ready.js";
import {
  registroCommand,
  handleRegistroButton,
  handleRegistroGender,
  handleRegistroRegion,
  handleRegistroPlatform,
  handleRegistroAge,
} from "./commands/registro.js";
import { avisoCommand, handleAvisoModal } from "./commands/aviso.js";
import { registradosCommand } from "./commands/registrados.js";
import { deployCommands } from "./commands/deploy.js";

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.DISCORD_CLIENT_ID;
const GUILD_ID = process.env.DISCORD_GUILD_ID;

if (!TOKEN) {
  throw new Error("DISCORD_TOKEN não configurado!");
}
if (!CLIENT_ID) {
  throw new Error("DISCORD_CLIENT_ID não configurado!");
}
if (!GUILD_ID) {
  throw new Error(
    "DISCORD_GUILD_ID não configurado! Adicione o ID do servidor nos Secrets."
  );
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds],
  partials: [Partials.Channel],
});

client.once(Events.ClientReady, async () => {
  await onReady(client);
  await deployCommands(CLIENT_ID!, GUILD_ID!, TOKEN!);
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (interaction.isChatInputCommand()) {
      const cmd = interaction as ChatInputCommandInteraction;
      if (cmd.commandName === "registro") {
        await registroCommand.execute(cmd);
      } else if (cmd.commandName === "aviso") {
        await avisoCommand.execute(cmd);
      } else if (cmd.commandName === "registrados") {
        await registradosCommand.execute(cmd);
      }
    }

    if (interaction.isButton()) {
      const btn = interaction as ButtonInteraction;
      await handleRegistroButton(btn);
    }

    if (interaction.isStringSelectMenu()) {
      const sel = interaction as StringSelectMenuInteraction;
      if (sel.customId.startsWith("reg_gender_")) {
        await handleRegistroGender(sel);
      } else if (sel.customId.startsWith("reg_region_")) {
        await handleRegistroRegion(sel);
      } else if (sel.customId.startsWith("reg_platform_")) {
        await handleRegistroPlatform(sel);
      } else if (sel.customId.startsWith("reg_age_")) {
        await handleRegistroAge(sel);
      }
    }

    if (interaction.isModalSubmit()) {
      const modal = interaction as ModalSubmitInteraction;
      if (modal.customId.startsWith("aviso_modal_")) {
        await handleAvisoModal(modal);
      }
    }
  } catch (err) {
    console.error("❌ Erro ao processar interação:", err);
  }
});

async function main() {
  console.log("🚀 Iniciando bot KarsenGG...");
  await initDatabase();
  await client.login(TOKEN);
}

main().catch(console.error);
