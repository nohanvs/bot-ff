import { Guild, GuildMember, Role } from "discord.js";

export const ROLE_DEFINITIONS = {
  registrado: { name: "✅ Registrado", color: 0xcc0000 as number },

  gender: {
    masculino: { name: "♂️ Masculino", color: 0x4a90d9 as number },
    feminino: { name: "♀️ Feminino", color: 0xe91e8c as number },
    outro: { name: "⚧ Prefiro não dizer", color: 0x9b59b6 as number },
  },

  region: {
    sudeste: { name: "🏙️ Sudeste", color: 0x95a5a6 as number },
    sul: { name: "🌾 Sul", color: 0x27ae60 as number },
    nordeste: { name: "🌵 Nordeste", color: 0xe67e22 as number },
    norte: { name: "🌳 Norte", color: 0x1abc9c as number },
    "centro-oeste": { name: "🌄 Centro-Oeste", color: 0xf39c12 as number },
    internacional: { name: "🌍 Internacional", color: 0x3498db as number },
  },

  platform: {
    mobile: { name: "📱 Mobile", color: 0x2ecc71 as number },
    emulador: { name: "💻 Emulador", color: 0x607d8b as number },
  },

  age: {
    "+18": { name: "🔞 +18", color: 0xe74c3c as number },
    "-18": { name: "👶 -18", color: 0x00bcd4 as number },
  },
} as const;

async function getOrCreateRole(
  guild: Guild,
  name: string,
  color: number
): Promise<Role> {
  const existing = guild.roles.cache.find((r) => r.name === name);
  if (existing) return existing;

  return await guild.roles.create({
    name,
    colors: [color],
    reason: "KarsenGG — criado automaticamente pelo sistema de registro",
  });
}

export async function assignRegistrationRoles(
  member: GuildMember,
  gender: string,
  region: string,
  platform: string,
  ageGroup: string
): Promise<void> {
  const guild = member.guild;

  const rolesToAssign: Role[] = [];

  const registradoRole = await getOrCreateRole(
    guild,
    ROLE_DEFINITIONS.registrado.name,
    ROLE_DEFINITIONS.registrado.color
  );
  rolesToAssign.push(registradoRole);

  const genderDef =
    ROLE_DEFINITIONS.gender[gender as keyof typeof ROLE_DEFINITIONS.gender];
  if (genderDef) {
    const genderRole = await getOrCreateRole(guild, genderDef.name, genderDef.color);
    rolesToAssign.push(genderRole);
  }

  const regionDef =
    ROLE_DEFINITIONS.region[region as keyof typeof ROLE_DEFINITIONS.region];
  if (regionDef) {
    const regionRole = await getOrCreateRole(guild, regionDef.name, regionDef.color);
    rolesToAssign.push(regionRole);
  }

  const platformDef =
    ROLE_DEFINITIONS.platform[platform as keyof typeof ROLE_DEFINITIONS.platform];
  if (platformDef) {
    const platformRole = await getOrCreateRole(guild, platformDef.name, platformDef.color);
    rolesToAssign.push(platformRole);
  }

  const ageDef =
    ROLE_DEFINITIONS.age[ageGroup as keyof typeof ROLE_DEFINITIONS.age];
  if (ageDef) {
    const ageRole = await getOrCreateRole(guild, ageDef.name, ageDef.color);
    rolesToAssign.push(ageRole);
  }

  await member.roles.add(rolesToAssign, "KarsenGG — registro concluído");
}

export function hasRegistradoRole(member: GuildMember): boolean {
  return member.roles.cache.some(
    (r) => r.name === ROLE_DEFINITIONS.registrado.name
  );
}
