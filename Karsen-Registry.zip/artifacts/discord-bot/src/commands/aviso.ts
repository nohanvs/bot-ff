import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  ActionRowBuilder,
  ModalSubmitInteraction,
  ChannelType,
  PermissionFlagsBits,
  TextChannel,
  MessageFlags,
} from "discord.js";

export const avisoCommand = {
  data: new SlashCommandBuilder()
    .setName("aviso")
    .setDescription("Envie um aviso para qualquer canal do servidor")
    .addChannelOption((opt) =>
      opt
        .setName("canal")
        .setDescription("Canal onde o aviso será enviado")
        .setRequired(true)
        .addChannelTypes(ChannelType.GuildText)
    )
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages),

  async execute(interaction: CommandInteraction) {
    const channel = interaction.options.get("canal")?.channel;

    if (!channel) {
      await interaction.reply({
        content: "❌ Canal inválido.",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    const modal = new ModalBuilder()
      .setCustomId(`aviso_modal_${channel.id}`)
      .setTitle("📢 Criar Aviso — KarsenGG");

    const tituloInput = new TextInputBuilder()
      .setCustomId("aviso_titulo")
      .setLabel("Título do aviso")
      .setStyle(TextInputStyle.Short)
      .setPlaceholder("Ex: Reunião de guilda | Evento especial")
      .setRequired(true)
      .setMaxLength(100);

    const mensagemInput = new TextInputBuilder()
      .setCustomId("aviso_mensagem")
      .setLabel("Mensagem (suporta espaços, emojis, etc.)")
      .setStyle(TextInputStyle.Paragraph)
      .setPlaceholder("Digite sua mensagem aqui... você pode usar espaços invisíveis, emojis e qualquer formatação Discord.")
      .setRequired(true)
      .setMaxLength(3900);

    const row1 = new ActionRowBuilder<TextInputBuilder>().addComponents(tituloInput);
    const row2 = new ActionRowBuilder<TextInputBuilder>().addComponents(mensagemInput);

    modal.addComponents(row1, row2);

    await interaction.showModal(modal);
  },
};

export async function handleAvisoModal(
  interaction: ModalSubmitInteraction
): Promise<void> {
  if (!interaction.customId.startsWith("aviso_modal_")) return;

  const channelId = interaction.customId.replace("aviso_modal_", "");
  const titulo = interaction.fields.getTextInputValue("aviso_titulo");
  const mensagem = interaction.fields.getTextInputValue("aviso_mensagem");

  await interaction.deferReply({ flags: MessageFlags.Ephemeral });

  try {
    const channel = await interaction.client.channels.fetch(channelId);

    if (!channel || !channel.isTextBased()) {
      await interaction.editReply({
        content: "❌ Canal não encontrado ou sem permissão.",
      });
      return;
    }

    const avisoEmbed = new EmbedBuilder()
      .setColor(0xcc0000)
      .setTitle(`📢 ${titulo}`)
      .setDescription(mensagem)
      .setFooter({
        text: `KarsenGG • Aviso enviado por ${interaction.user.username}`,
        iconURL: interaction.user.displayAvatarURL({ extension: "png" }) ?? undefined,
      })
      .setTimestamp();

    const textChannel = channel as TextChannel;
    await textChannel.send({ embeds: [avisoEmbed] });

    await interaction.editReply({
      content: `✅ Aviso enviado com sucesso em <#${channelId}>!`,
    });
  } catch (err) {
    console.error("Erro ao enviar aviso:", err);
    await interaction.editReply({
      content: "❌ Erro ao enviar o aviso. Verifique se o bot tem permissão no canal.",
    });
  }
}
