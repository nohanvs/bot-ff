import {
  SlashCommandBuilder,
  ChatInputCommandInteraction,
  EmbedBuilder,
  GuildMember,
  MessageFlags,
} from "discord.js";
import { db, registrations } from "../database/db.js";
import { hasRegistradoRole } from "../utils/roles.js";

export const registradosCommand = {
  data: new SlashCommandBuilder()
    .setName("registrados")
    .setDescription("Veja os membros registrados da guilda KarsenGG"),

  async execute(interaction: ChatInputCommandInteraction) {
    const member = interaction.member as GuildMember | null;

    if (!member || !hasRegistradoRole(member)) {
      await interaction.reply({
        content:
          "❌ Apenas membros **registrados** podem usar este comando.\nUse `/registro` para se registrar primeiro!",
        flags: MessageFlags.Ephemeral,
      });
      return;
    }

    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    try {
      const allRegistrations = await db.select().from(registrations);

      if (allRegistrations.length === 0) {
        await interaction.editReply({
          content: "📭 Nenhum membro registrado ainda.",
        });
        return;
      }

      const genderLabels: Record<string, string> = {
        masculino: "♂️",
        feminino: "♀️",
        outro: "⚧",
      };
      const regionLabels: Record<string, string> = {
        sudeste: "🏙️",
        sul: "🌾",
        nordeste: "🌵",
        norte: "🌳",
        "centro-oeste": "🌄",
        internacional: "🌍",
      };
      const platformLabels: Record<string, string> = {
        mobile: "📱",
        emulador: "💻",
      };

      const total = allRegistrations.length;
      const byGender = {
        masculino: allRegistrations.filter((r) => r.gender === "masculino").length,
        feminino: allRegistrations.filter((r) => r.gender === "feminino").length,
        outro: allRegistrations.filter((r) => r.gender === "outro").length,
      };
      const byPlatform = {
        mobile: allRegistrations.filter((r) => r.platform === "mobile").length,
        emulador: allRegistrations.filter((r) => r.platform === "emulador").length,
      };
      const byAge = {
        "+18": allRegistrations.filter((r) => r.ageGroup === "+18").length,
        "-18": allRegistrations.filter((r) => r.ageGroup === "-18").length,
      };

      const PAGE_SIZE = 10;
      const recent = allRegistrations
        .sort(
          (a, b) =>
            new Date(b.registeredAt).getTime() - new Date(a.registeredAt).getTime()
        )
        .slice(0, PAGE_SIZE);

      const memberList = recent
        .map((r, i) => {
          const g = genderLabels[r.gender] ?? "❓";
          const reg = regionLabels[r.region] ?? "🌐";
          const p = platformLabels[r.platform] ?? "🎮";
          const age = r.ageGroup;
          return `\`${String(i + 1).padStart(2, "0")}\` <@${r.userId}> ${g} ${reg} ${p} \`${age}\``;
        })
        .join("\n");

      const embed = new EmbedBuilder()
        .setColor(0xcc0000)
        .setTitle("📋 Membros Registrados — KarsenGG")
        .setDescription(
          `Mostrando os **${recent.length}** mais recentes de **${total}** registrados.\n\n${memberList}`
        )
        .addFields(
          {
            name: "👤 Gênero",
            value:
              `♂️ Masculino: **${byGender.masculino}**\n` +
              `♀️ Feminino: **${byGender.feminino}**\n` +
              `⚧ Outro: **${byGender.outro}**`,
            inline: true,
          },
          {
            name: "🎮 Plataforma",
            value:
              `📱 Mobile: **${byPlatform.mobile}**\n` +
              `💻 Emulador: **${byPlatform.emulador}**`,
            inline: true,
          },
          {
            name: "🔢 Faixa Etária",
            value:
              `🔞 +18: **${byAge["+18"]}**\n` +
              `👶 -18: **${byAge["-18"]}**`,
            inline: true,
          }
        )
        .setFooter({
          text: `KarsenGG • Total: ${total} membros registrados`,
        })
        .setTimestamp();

      await interaction.editReply({ embeds: [embed] });
    } catch (err) {
      console.error("Erro ao buscar registrados:", err);
      await interaction.editReply({
        content: "❌ Erro ao buscar os registros. Tente novamente.",
      });
    }
  },
};
