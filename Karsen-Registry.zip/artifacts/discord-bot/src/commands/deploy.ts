import { REST, Routes } from "discord.js";
import { registroCommand } from "./registro.js";
import { avisoCommand } from "./aviso.js";
import { registradosCommand } from "./registrados.js";

const commands = [
  registroCommand.data.toJSON(),
  avisoCommand.data.toJSON(),
  registradosCommand.data.toJSON(),
];

export async function deployCommands(
  clientId: string,
  guildId: string,
  token: string
) {
  const rest = new REST({ version: "10" }).setToken(token);

  try {
    console.log("📡 Limpando comandos globais antigos...");
    await rest.put(Routes.applicationCommands(clientId), { body: [] });

    console.log(`📡 Registrando slash commands no servidor (${guildId})...`);
    await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
      body: commands,
    });

    console.log("✅ Slash commands registrados instantaneamente no servidor!");
  } catch (error: any) {
    if (error?.code === 50001) {
      console.error("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
      console.error("❌ ERRO: Bot sem acesso ao servidor!");
      console.error("   O bot precisa ser convidado com o escopo correto.");
      console.error("   Use este link para convidar o bot ao seu servidor:");
      console.error(
        `   https://discord.com/oauth2/authorize?client_id=${clientId}&permissions=8&integration_type=0&scope=bot+applications.commands`
      );
      console.error("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    } else {
      console.error("❌ Erro ao registrar commands:", error);
    }
  }
}

export async function removeCommands(
  clientId: string,
  guildId: string,
  token: string
) {
  const rest = new REST({ version: "10" }).setToken(token);

  try {
    console.log("🗑️ Removendo todos os comandos do servidor...");
    await rest.put(Routes.applicationGuildCommands(clientId, guildId), {
      body: [],
    });
    await rest.put(Routes.applicationCommands(clientId), { body: [] });
    console.log("✅ Todos os comandos removidos com sucesso!");
  } catch (error) {
    console.error("❌ Erro ao remover commands:", error);
  }
}
