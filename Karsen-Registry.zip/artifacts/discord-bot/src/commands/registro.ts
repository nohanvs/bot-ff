import {
  SlashCommandBuilder,
  CommandInteraction,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  StringSelectMenuInteraction,
  ButtonInteraction,
  ModalSubmitInteraction,
  ComponentType,
  Colors,
  PermissionFlagsBits,
  GuildMember,
  MessageFlags,
} from "discord.js";
import { db, registrations } from "../database/db.js";
import { eq } from "drizzle-orm";
import { assignRegistrationRoles } from "../utils/roles.js";

export const registroCommand = {
  data: new SlashCommandBuilder()
    .setName("registro")
    .setDescription("Abra o painel de registro da guilda KarsenGG"),

  async execute(interaction: CommandInteraction) {
    const embed = new EmbedBuilder()
      .setColor(0xcc0000)
      .setTitle("🔴 REGISTRO — KarsenGG")
      .setDescription(
        "**Bem-vindo(a) à KarsenGG!**\n\n" +
          "Para ter acesso completo ao servidor, você precisa se registrar.\n" +
          "Clique no botão abaixo para iniciar o seu cadastro.\n\n" +
          "```\nℹ️ O processo é rápido e fácil!\n```"
      )
      .setThumbnail(
        interaction.guild?.iconURL({ extension: "png" }) ??
          "https://i.imgur.com/4M34hi2.png"
      )
      .setFooter({
        text: "KarsenGG • Sistema de Registro",
        iconURL:
          interaction.guild?.iconURL({ extension: "png" }) ?? undefined,
      })
      .setTimestamp();

    const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
      new ButtonBuilder()
        .setCustomId("iniciar_registro")
        .setLabel("✅  Registrar-se")
        .setStyle(ButtonStyle.Danger)
    );

    await interaction.reply({
      embeds: [embed],
      components: [row],
    });
  },
};

export async function handleRegistroButton(
  interaction: ButtonInteraction
): Promise<void> {
  if (interaction.customId !== "iniciar_registro") return;

  const existing = await db
    .select()
    .from(registrations)
    .where(eq(registrations.userId, interaction.user.id))
    .limit(1);

  if (existing.length > 0) {
    await interaction.reply({
      content:
        "❌ Você já está registrado(a) na KarsenGG! Caso precise alterar seu registro, contate um administrador.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(0xcc0000)
    .setTitle("📋 Registro — Etapa 1 de 3")
    .setDescription(
      "**Selecione o seu gênero:**\n\n" +
        "Escolha uma das opções abaixo para prosseguir."
    )
    .setFooter({ text: "KarsenGG • Registro" });

  const genderRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`reg_gender_${interaction.user.id}`)
      .setPlaceholder("Selecione seu gênero...")
      .addOptions([
        { label: "♂️ Masculino", value: "masculino", emoji: "♂️" },
        { label: "♀️ Feminino", value: "feminino", emoji: "♀️" },
        { label: "⚧ Prefiro não dizer", value: "outro", emoji: "⚧" },
      ])
  );

  await interaction.reply({
    embeds: [embed],
    components: [genderRow],
    flags: MessageFlags.Ephemeral,
  });
}

export async function handleRegistroGender(
  interaction: StringSelectMenuInteraction
): Promise<void> {
  if (!interaction.customId.startsWith("reg_gender_")) return;
  const userId = interaction.customId.replace("reg_gender_", "");
  if (interaction.user.id !== userId) {
    await interaction.reply({
      content: "❌ Este menu não é para você.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const gender = interaction.values[0];

  const embed = new EmbedBuilder()
    .setColor(0xcc0000)
    .setTitle("📋 Registro — Etapa 2 de 3")
    .setDescription(
      "**Selecione sua região:**\n\n" +
        "Em qual região do Brasil você joga?"
    )
    .setFooter({ text: "KarsenGG • Registro" });

  const regionRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`reg_region_${userId}_${gender}`)
      .setPlaceholder("Selecione sua região...")
      .addOptions([
        { label: "🏙️ Sudeste (SP, RJ, MG, ES)", value: "sudeste" },
        { label: "🌾 Sul (RS, SC, PR)", value: "sul" },
        { label: "🌵 Nordeste", value: "nordeste" },
        { label: "🌳 Norte", value: "norte" },
        { label: "🌄 Centro-Oeste", value: "centro-oeste" },
        { label: "🌍 Internacional", value: "internacional" },
      ])
  );

  await interaction.update({
    embeds: [embed],
    components: [regionRow],
  });
}

export async function handleRegistroRegion(
  interaction: StringSelectMenuInteraction
): Promise<void> {
  if (!interaction.customId.startsWith("reg_region_")) return;
  const parts = interaction.customId.replace("reg_region_", "").split("_");
  const userId = parts[0];
  const gender = parts[1];
  if (interaction.user.id !== userId) {
    await interaction.reply({
      content: "❌ Este menu não é para você.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const region = interaction.values[0];

  const embed = new EmbedBuilder()
    .setColor(0xcc0000)
    .setTitle("📋 Registro — Etapa 3 de 3")
    .setDescription(
      "**Últimas informações:**\n\n" +
        "Selecione como você joga e sua faixa etária."
    )
    .setFooter({ text: "KarsenGG • Registro" });

  const platformRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`reg_platform_${userId}_${gender}_${region}`)
      .setPlaceholder("Selecione como você joga...")
      .addOptions([
        { label: "📱 Mobile (celular)", value: "mobile", emoji: "📱" },
        { label: "💻 Emulador (PC)", value: "emulador", emoji: "💻" },
      ])
  );

  await interaction.update({
    embeds: [embed],
    components: [platformRow],
  });
}

export async function handleRegistroPlatform(
  interaction: StringSelectMenuInteraction
): Promise<void> {
  if (!interaction.customId.startsWith("reg_platform_")) return;
  const parts = interaction.customId.replace("reg_platform_", "").split("_");
  const userId = parts[0];
  const gender = parts[1];
  const region = parts[2];
  if (interaction.user.id !== userId) {
    await interaction.reply({
      content: "❌ Este menu não é para você.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const platform = interaction.values[0];

  const embed = new EmbedBuilder()
    .setColor(0xcc0000)
    .setTitle("📋 Registro — Faixa Etária")
    .setDescription("**Qual é sua faixa etária?**")
    .setFooter({ text: "KarsenGG • Registro" });

  const ageRow = new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(
    new StringSelectMenuBuilder()
      .setCustomId(`reg_age_${userId}_${gender}_${region}_${platform}`)
      .setPlaceholder("Selecione sua faixa etária...")
      .addOptions([
        { label: "🔞 +18 anos", value: "+18" },
        { label: "👶 -18 anos", value: "-18" },
      ])
  );

  await interaction.update({
    embeds: [embed],
    components: [ageRow],
  });
}

export async function handleRegistroAge(
  interaction: StringSelectMenuInteraction
): Promise<void> {
  if (!interaction.customId.startsWith("reg_age_")) return;
  const parts = interaction.customId.replace("reg_age_", "").split("_");
  const userId = parts[0];
  const gender = parts[1];
  const region = parts[2];
  const platform = parts[3];
  if (interaction.user.id !== userId) {
    await interaction.reply({
      content: "❌ Este menu não é para você.",
      flags: MessageFlags.Ephemeral,
    });
    return;
  }

  const ageGroup = interaction.values[0];

  await interaction.deferUpdate();

  try {
    await db.insert(registrations).values({
      userId: interaction.user.id,
      username: interaction.user.username,
      gender,
      region,
      platform,
      ageGroup,
    });

    const member = interaction.member as GuildMember | null;
    if (member) {
      try {
        await assignRegistrationRoles(member, gender, region, platform, ageGroup);
      } catch (roleErr) {
        console.error("⚠️ Erro ao atribuir cargos (o registro foi salvo mesmo assim):", roleErr);
      }
    }

    const genderLabel =
      gender === "masculino" ? "♂️ Masculino" : gender === "feminino" ? "♀️ Feminino" : "⚧ Prefiro não dizer";
    const regionLabels: Record<string, string> = {
      sudeste: "🏙️ Sudeste",
      sul: "🌾 Sul",
      nordeste: "🌵 Nordeste",
      norte: "🌳 Norte",
      "centro-oeste": "🌄 Centro-Oeste",
      internacional: "🌍 Internacional",
    };
    const platformLabel = platform === "mobile" ? "📱 Mobile" : "💻 Emulador";

    const successEmbed = new EmbedBuilder()
      .setColor(0xcc0000)
      .setTitle("✅ Registro Concluído!")
      .setDescription(
        `Bem-vindo(a) à **KarsenGG**, <@${interaction.user.id}>! 🎉\n\n` +
          "Seu perfil foi salvo com sucesso e seus **cargos foram atribuídos** automaticamente."
      )
      .addFields(
        { name: "👤 Gênero", value: genderLabel, inline: true },
        { name: "🗺️ Região", value: regionLabels[region] ?? region, inline: true },
        { name: "🎮 Plataforma", value: platformLabel, inline: true },
        { name: "🔢 Faixa Etária", value: ageGroup, inline: true }
      )
      .setThumbnail(
        interaction.user.displayAvatarURL({ extension: "png" }) ?? null
      )
      .setFooter({ text: "KarsenGG • Registro" })
      .setTimestamp();

    await interaction.editReply({
      embeds: [successEmbed],
      components: [],
    });
  } catch (err) {
    console.error("Erro ao registrar:", err);
    await interaction.editReply({
      content:
        "❌ Ocorreu um erro ao salvar seu registro. Tente novamente mais tarde.",
      embeds: [],
      components: [],
    });
  }
}
