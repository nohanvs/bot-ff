import { Client, ActivityType } from "discord.js";

export async function onReady(client: Client) {
  console.log(`✅ Bot online como ${client.user?.tag}`);

  client.user?.setPresence({
    status: "dnd",
    activities: [
      {
        name: "dev novak9j",
        type: ActivityType.Custom,
        state: "dev novak9j",
      },
    ],
  });

  console.log("🔴 Status DND configurado | dev novak9j");
}
