import pg from "pg";
import { drizzle } from "drizzle-orm/node-postgres";
import {
  pgTable,
  serial,
  text,
  varchar,
  boolean,
  timestamp,
  integer,
} from "drizzle-orm/pg-core";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL must be set.");
}

export const pool = new Pool({ connectionString: process.env.DATABASE_URL });

export const registrations = pgTable("karsengg_registrations", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id", { length: 30 }).notNull().unique(),
  username: text("username").notNull(),
  gender: varchar("gender", { length: 10 }).notNull(),
  region: varchar("region", { length: 20 }).notNull(),
  platform: varchar("platform", { length: 20 }).notNull(),
  ageGroup: varchar("age_group", { length: 10 }).notNull(),
  registeredAt: timestamp("registered_at").defaultNow().notNull(),
});

export const db = drizzle(pool, { schema: { registrations } });

export async function initDatabase() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS karsengg_registrations (
      id SERIAL PRIMARY KEY,
      user_id VARCHAR(30) NOT NULL UNIQUE,
      username TEXT NOT NULL,
      gender VARCHAR(10) NOT NULL,
      region VARCHAR(20) NOT NULL,
      platform VARCHAR(20) NOT NULL,
      age_group VARCHAR(10) NOT NULL,
      registered_at TIMESTAMP DEFAULT NOW() NOT NULL
    )
  `);
  console.log("✅ Banco de dados inicializado");
}
